package com.example.keycloak;
import org.junit.jupiter.api.Test;
import org.keycloak.models.*;
import org.keycloak.events.admin.*;
import org.mockito.ArgumentCaptor;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
class AdminScimEventListenerProviderTest {
    @Test void readsFullStateWithoutRepresentationAndWaitsForCommit() {
        KeycloakSession session = mock(KeycloakSession.class,RETURNS_DEEP_STUBS);
        RealmModel realm = mock(RealmModel.class); UserModel user = mock(UserModel.class);
        when(session.realms().getRealm("r")).thenReturn(realm);
        when(session.users().getUserById(realm,"u")).thenReturn(user);
        when(user.getUsername()).thenReturn("alice"); when(user.getAttributes()).thenReturn(Map.of());
        OutboundScimProvider adapter = mock(OutboundScimProvider.class);
        AdminEvent event = new AdminEvent(); event.setRealmId("r"); event.setResourcePath("users/u"); event.setResourceType(ResourceType.USER); event.setOperationType(OperationType.UPDATE);
        new AdminScimEventListenerProvider(session,adapter).onEvent(event,false);
        verifyNoInteractions(adapter);
        ArgumentCaptor<KeycloakTransaction> captor=ArgumentCaptor.forClass(KeycloakTransaction.class);
        verify(session.getTransactionManager()).enlistAfterCompletion(captor.capture());
        captor.getValue().begin(); captor.getValue().commit();
        verify(adapter).handleEvent(argThat(m -> ((Map<?,?>)m.get("user")).get("username").equals("alice")));
    }
    @Test void rollbackDoesNotSend() {
        KeycloakSession session=mock(KeycloakSession.class,RETURNS_DEEP_STUBS);
        OutboundScimProvider adapter=mock(OutboundScimProvider.class);
        AdminEvent event=new AdminEvent(); event.setResourcePath("users/u"); event.setResourceType(ResourceType.USER); event.setOperationType(OperationType.DELETE);
        new AdminScimEventListenerProvider(session,adapter).onEvent(event,false);
        ArgumentCaptor<KeycloakTransaction> captor=ArgumentCaptor.forClass(KeycloakTransaction.class);
        verify(session.getTransactionManager()).enlistAfterCompletion(captor.capture());
        captor.getValue().begin(); captor.getValue().rollback(); verifyNoInteractions(adapter);
    }
}
