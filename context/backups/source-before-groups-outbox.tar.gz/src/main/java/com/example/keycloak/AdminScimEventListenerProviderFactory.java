package com.example.keycloak;

import com.example.scim.ScimClient;
import org.keycloak.Config;
import org.keycloak.events.EventListenerProvider;
import org.keycloak.events.EventListenerProviderFactory;
import org.keycloak.models.*;
import java.net.URI;

public class AdminScimEventListenerProviderFactory implements EventListenerProviderFactory {
    private OutboundScimProvider adapter;
    public EventListenerProvider create(KeycloakSession session) { return new AdminScimEventListenerProvider(session, adapter); }
    public void init(Config.Scope config) {
        String base = System.getProperty("scim.baseUrl", config.get("base-url"));
        // An unconfigured listener is inert; other realms can run without SCIM.
        if (base == null || base.isBlank()) return;
        String token = System.getProperty("scim.bearerToken", config.get("bearer-token"));
        boolean deactivate = Boolean.parseBoolean(System.getProperty("scim.deleteAsDeactivate", config.get("delete-as-deactivate", "false")));
        adapter = new OutboundScimProvider(new ScimClient(URI.create(base), token), deactivate);
    }
    public void postInit(KeycloakSessionFactory factory) { }
    public void close() { }
    public String getId() { return "scim-admin-listener"; }
}
