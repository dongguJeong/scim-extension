package com.example.keycloak;

import com.example.scim.ScimException;
import org.keycloak.events.Event;
import org.keycloak.events.EventListenerProvider;
import org.keycloak.events.admin.*;
import org.keycloak.models.*;
import java.util.*;

/** Captures persisted state and dispatches only after a successful transaction. */
public class AdminScimEventListenerProvider implements EventListenerProvider {
    private static final System.Logger LOG = System.getLogger(AdminScimEventListenerProvider.class.getName());
    private final KeycloakSession session;
    private final OutboundScimProvider adapter;
    public AdminScimEventListenerProvider(KeycloakSession session, OutboundScimProvider adapter) {
        this.session = session; this.adapter = adapter;
    }
    public void onEvent(Event event) { }
    public void onEvent(AdminEvent event, boolean includeRepresentation) {
        if (adapter == null || event.getError() != null || event.getResourceType() != ResourceType.USER) return;
        OperationType op = event.getOperationType();
        if (op != OperationType.CREATE && op != OperationType.UPDATE && op != OperationType.DELETE) return;
        String path = event.getResourcePath();
        if (path == null || !path.matches("users/[^/]+")) return;
        String id = path.substring(6);
        Map<String,Object> snapshot = new HashMap<>();
        snapshot.put("id", id);
        if (op != OperationType.DELETE) {
            RealmModel realm = session.realms().getRealm(event.getRealmId());
            UserModel user = realm == null ? null : session.users().getUserById(realm, id);
            if (user == null) { LOG.log(System.Logger.Level.ERROR, "SCIM user snapshot unavailable: " + id); return; }
            snapshot.put("username", user.getUsername());
            snapshot.put("enabled", user.isEnabled());
            snapshot.put("email", user.getEmail());
            snapshot.put("firstName", user.getFirstName());
            snapshot.put("lastName", user.getLastName());
            Map<String,List<String>> attributes = new HashMap<>();
            user.getAttributes().forEach((key,values) -> attributes.put(key, new ArrayList<>(values)));
            snapshot.put("attributes", attributes);
        }
        Map<String,Object> message = Map.of("type", op.name(), "user", snapshot);
        session.getTransactionManager().enlistAfterCompletion(new AbstractKeycloakTransaction() {
            protected void commitImpl() { dispatch(message, id); }
            protected void rollbackImpl() { }
        });
    }
    private void dispatch(Map<String,Object> message, String id) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            try { adapter.handleEvent(message); return; }
            catch (ScimException e) {
                if (!e.isRetryable() || attempt == 3 || Thread.currentThread().isInterrupted()) {
                    LOG.log(System.Logger.Level.ERROR, "SCIM sync failed for " + id + "; status=" + e.getStatus() + "; manual reconciliation required");
                    return;
                }
                try { Thread.sleep(200L * attempt); }
                catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); return; }
            } catch (RuntimeException e) {
                LOG.log(System.Logger.Level.ERROR, "SCIM mapping failed for " + id + "; " + e.getClass().getSimpleName()); return;
            }
        }
    }
    public void close() { }
}
