# Keycloak SCIM Outbound Extension

Keycloak **26.7.3 / Java 21**용 관리자 사용자 이벤트 리스너입니다.

- 실제 `EventListenerProviderFactory` SPI: `scim-admin-listener`
- 관리자 사용자 CREATE/UPDATE/DELETE만 처리합니다. 그룹 및 셀프서비스 이벤트는 지원하지 않습니다.
- Keycloak UUID → SCIM externalId. SCIM id는 서버에서 할당합니다.
- CREATE/UPDATE는 externalId 검색 후 생성 또는 PUT합니다. PUT에는 UserModel의 전체 스냅샷을 사용합니다.
- enabled, 이름, 이메일, phoneNumber 및 RBAC 커스텀 속성을 매핑합니다.
- 트랜잭션 커밋 성공 후 전송하며, 롤백 시 전송하지 않습니다.
- 429/5xx/네트워크 오류는 최대 3회 시도합니다. 영구 큐는 없으며 최종 실패는 서버 로그에 기록됩니다.

## 빌드

JDK 21 + Maven: `mvn -B clean verify`

또는 Docker:

```bash
docker run --rm -v "$PWD:/workspace" -v scim-extension-maven-cache:/root/.m2 \
  -w /workspace maven:3.9.11-eclipse-temurin-21 mvn -B clean verify
```

출력: `target/scim-outbound-extension-0.1.0.jar`

## 설정 및 배포

JAR을 Keycloak providers에 배치한 후 Keycloak을 다시 빌드/시작합니다. 실행 중 JAR 파일만 복사해도 자동 적용되는 방식은 아닙니다.

- `-Dscim.baseUrl=http://host.docker.internal:3000/scim/v2`
- `-Dscim.bearerToken=...` (선택)
- `-Dscim.deleteAsDeactivate=true` (기본 false)

동일한 SPI 설정 키는 `base-url`, `bearer-token`, `delete-as-deactivate`입니다. base URL이 없으면 리스너는 비활성 상태입니다.
대상 Realm의 Event listeners에 `scim-admin-listener`를 추가해야 합니다.
컨테이너에서 호스트 SCIM에 접근할 때 `127.0.0.1` 대신 `host.docker.internal` 또는 적절한 Docker 서비스 DNS를 사용합니다.

## 테스트

SCIM API와 DB를 실행한 후:

```bash
./integration/run-e2e.sh
SKIP_BUILD=true DELETE_AS_DEACTIVATE=true ./integration/run-e2e.sh
```

기존 Keycloak은 유지하고 포트 18080의 임시 Keycloak 26.7.3에서 빌드한 JAR을 테스트합니다.
테스트 Realm/사용자와 임시 컨테이너는 정리합니다. 자세한 절차와 제한은 `docx.md`를 참고하세요.
